//
//  CalendarView.swift
//  CirculerCalendarDemo
//
//  Created by Bhavik's Mac on 31/10/18.
//  Copyright © 2018 Bhavik Barot. All rights reserved.
//

import UIKit
import Foundation

class CalendarView: UIView {
    
    private var mainView = UIView()
    private var btnReset = UIButton()
    private var lblMonthAndYear = UILabel()
    private var lblDayString = UILabel()
    private var gradientBottumView = UIView()
    private var calendarMainView = UIView()
    private var layoutForCollectionView = CircularCollectionViewLayout()
    private var calendarReloadIndicator = UIActivityIndicatorView()
    private var calendarCollectionView: UICollectionView!
    
    fileprivate var isReloadToReset: Bool! = true
    fileprivate var currentDateDayCount = Int()
    fileprivate var currentDateMonthCount = Int()
    fileprivate var currentDateYearCount = Int()
    fileprivate var calendarDataArr:[CalendarDateModel] = []
    fileprivate var currentCalIndex = Int()
    
    fileprivate let gregorian = Calendar(identifier: .gregorian)
    fileprivate let formatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }()
    
    fileprivate lazy var calendarDatasource: CalendarDatasource = {
        let calendarDatasource = CalendarDatasource()
        return calendarDatasource
    }()
    
    fileprivate lazy var calendarDelegate: CalendarDelegate = {
        let calendarDelegate = CalendarDelegate()
        return calendarDelegate
    }()
    
    static let shared: CalendarView = {
        let calView = CalendarView()
        return calView
    }()
    
    var delegate: BHCalendarDelegate?
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .clear
        self.calendarCollectionView = UICollectionView(frame: self.frame, collectionViewLayout: self.layoutForCollectionView)
        self.calendarCollectionView.showsVerticalScrollIndicator = false
        self.calendarCollectionView.showsHorizontalScrollIndicator = false
        self.setDefaultUI()
    }
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func draw(_ rect: CGRect) {
        self.setupView()
    }
}

//MARK:- Private Methods.
extension CalendarView {
    
    private func setupView() {
        self.addSubview(self.mainView)
        self.addSubViewsToSuperView()
        self.disableAutoResizingMasks()
        self.setupConstraints()
    }
    
    private func setDefaultUI() {
        self.calendarCollectionView.backgroundColor = .clear
        self.backgroundColor = .clear
        self.mainView.backgroundColor = .gray
        self.calendarMainView.backgroundColor = .clear
        self.gradientBottumView.backgroundColor = .blue
        self.lblMonthAndYear.textAlignment = .center
        self.lblMonthAndYear.textColor = .white
        self.lblDayString.textColor = .white
        self.calendarReloadIndicator.style = .whiteLarge
        self.resetButtonBackgroundImage = UIImage(named: "resetCalendar")
    }
    
    private func setupCells() {
        self.calendarCollectionView.register(UINib(nibName: "CalendarCollectionViewCell", bundle: Bundle.main), forCellWithReuseIdentifier: "CalendarCollectionViewCell")
    }
    
    private func setupSelectors() {
        self.btnReset.addTarget(self, action: #selector(btnResetAction(_:)), for: .touchUpInside)
    }
    
    private func setupUI() {
        self.mainView.layoutIfNeeded()
        self.mainView.setNeedsLayout()
        self.mainView.layer.cornerRadius = self.mainView.bounds.size.width / 2
        
        self.calendarMainView.layoutIfNeeded()
        self.calendarMainView.setNeedsLayout()
        self.calendarMainView.layer.cornerRadius = self.calendarMainView.bounds.width / 2
        
        self.gradientBottumView.layoutIfNeeded()
        self.gradientBottumView.setNeedsLayout()
        self.gradientBottumView.layer.cornerRadius = self.gradientBottumView.bounds.size.width / 2
        self.setDefaultDate()
    }
}

//MARK:- Main View Property Setup
extension CalendarView {
    var calendarBackgroundColor: UIColor! {
        set {
            self.mainView.backgroundColor = newValue
        }
        get {
            return self.mainView.backgroundColor
        }
    }
}

//MARK:- Gradient View Property Setup
extension CalendarView {
    var bottomViewBackgroundColor: UIColor! {
        set {
            self.gradientBottumView.backgroundColor = newValue
        }
        get {
            return self.gradientBottumView.backgroundColor
        }
    }
    
    var bottomViewCornerRedius: CGFloat! {
        set {
            self.gradientBottumView.layer.cornerRadius = newValue
        }
        get {
            return self.gradientBottumView.layer.cornerRadius
        }
    }
    
    var gradientForBottumView: CAGradientLayer {
        set {
            for layer in self.gradientBottumView.layer.sublayers! {
                if layer is CAGradientLayer {
                    layer.removeFromSuperlayer()
                }
            }
            newValue.frame = self.gradientBottumView.bounds
            
            newValue.cornerRadius = mainView.bounds.size.width / 2
            self.gradientBottumView.layer.insertSublayer(newValue, at: 0)
        }
        get {
            for layer in self.gradientBottumView.layer.sublayers! {
                if layer is CAGradientLayer {
                    return layer as! CAGradientLayer
                }
            }
            return CAGradientLayer()
        }
    }
}

//MARK:- Reset Button Property Setup
extension CalendarView {
    var resetButtonBackgroundColor: UIColor! {
        set {
            self.btnReset.backgroundColor = newValue
        }
        get {
            return self.btnReset.backgroundColor
        }
    }
    
    var resetButtonBackgroundImage: UIImage? {
        set {
            self.btnReset.setBackgroundImage(newValue, for: .normal)
        }
        get {
            return self.btnReset.currentBackgroundImage
        }
    }
    
    var resetButtonTitle: String! {
        set {
            self.btnReset.setTitle(newValue, for: .normal)
        }
        get {
            return self.btnReset.title(for: .normal)
        }
    }
    
    var resetButtonTitleForNormalState: String! {
        set {
            self.btnReset.setTitle(newValue, for: .normal)
        }
        get {
            return self.btnReset.title(for: .normal)
        }
    }
    
    var resetButtonTitleForSelectedState: String! {
        set {
            self.btnReset.setTitle(newValue, for: .selected)
        }
        get {
            return self.btnReset.title(for: .selected)
        }
    }
}

//MARK:- Month and Year Label Property Setup
extension CalendarView {
    var infoLabelTextColor: UIColor! {
        set {
            self.lblMonthAndYear.textColor = newValue
        }
        get {
            return self.lblMonthAndYear.textColor
        }
    }
    
    var infoLabelTextAlignment: NSTextAlignment! {
        set {
            self.lblMonthAndYear.textAlignment = newValue
        }
        get {
            return self.lblMonthAndYear.textAlignment
        }
    }
}

//MARK:- Day Label Property Setup
extension CalendarView {
    var dayLabelTextColor: UIColor! {
        set {
            self.lblDayString.textColor = newValue
        }
        get {
            return self.lblDayString.textColor
        }
    }
    
    var dayLabelTextAlignment: NSTextAlignment! {
        set {
            self.lblDayString.textAlignment = newValue
        }
        get {
            return self.lblDayString.textAlignment
        }
    }
}

//MARK:- Extra Property
extension CalendarView {
    var getCurrentSelectedDate: String! {
        get {
            return self.getSelectedDate()
        }
    }
}

//MARK:- Selectors
extension CalendarView {
    @objc private func btnResetAction(_ sender: UIButton) {
        if self.btnReset.isEnabled {
            self.setDefaultDate()
        }
        
        if self.delegate != nil {
            self.delegate?.resetButtonClicked(sender)
        }
    }
}

//MARK:- Add Subviews to SuperViews
extension CalendarView {
    private func addSubViewsToSuperView() {
        
        //For MainView
        self.mainView.addSubview(self.calendarMainView)
        self.mainView.addSubview(self.gradientBottumView)
        self.mainView.addSubview(self.lblDayString)
        self.mainView.addSubview(self.btnReset)
        
        //For Bottom View
        self.gradientBottumView.addSubview(self.lblMonthAndYear)
        
        //For CollectionView Main
        self.calendarMainView.addSubview(self.calendarCollectionView)
        self.calendarMainView.addSubview(self.calendarReloadIndicator)
        self.calendarMainView.bringSubviewToFront(self.calendarReloadIndicator)
        self.calendarMainView.sendSubviewToBack(self.calendarCollectionView)
    }
}
//MARK:- Constraint Mode
extension CalendarView {
    
    private func disableAutoResizingMasks() {
        self.translatesAutoresizingMaskIntoConstraints = false
        self.mainView.translatesAutoresizingMaskIntoConstraints = false
        self.btnReset.translatesAutoresizingMaskIntoConstraints = false
        self.lblMonthAndYear.translatesAutoresizingMaskIntoConstraints = false
        self.lblDayString.translatesAutoresizingMaskIntoConstraints = false
        self.gradientBottumView.translatesAutoresizingMaskIntoConstraints = false
        self.calendarMainView.translatesAutoresizingMaskIntoConstraints = false
        self.calendarCollectionView.translatesAutoresizingMaskIntoConstraints = false
        self.calendarReloadIndicator.translatesAutoresizingMaskIntoConstraints = false
    }
    
    private func setupConstraints() {
        self.setupConstraintsForSelf()
        self.setupConstraintsMainView()
        self.setupConstraintsCalendarMainView()
        self.setupConstraintsCalendarCollectionView()
        self.setupConstraintsCalendarReloadIndicator()
        self.setupConstraintsGradientBottumView()
        self.setupConstraintsBtnReset()
        self.setupConstraintsLblDayString()
        self.setupConstraintsLblMonthAndYear()

        self.setupCells()
        self.setupSelectors()
        self.setupUI()
    }
    
    private func setupConstraintsForSelf() {
        if self.superview != nil {
            self.widthAnchor.constraint(equalToConstant: 295)
            self.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1).isActive = true
            self.topAnchor.constraint(equalTo: self.superview!.topAnchor).isActive = true
            self.bottomAnchor.constraint(equalTo: self.superview!.bottomAnchor).isActive = true
            self.leftAnchor.constraint(equalTo: self.superview!.leftAnchor).isActive = true
            self.rightAnchor.constraint(equalTo: self.superview!.rightAnchor).isActive = true
        }
        else {
            self.translatesAutoresizingMaskIntoConstraints = false
            self.widthAnchor.constraint(equalToConstant: 295)
            self.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1).isActive = true
        }
    }
    
    private func setupConstraintsMainView() {
        self.mainView.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
        self.mainView.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
        self.mainView.leftAnchor.constraint(equalTo: self.leftAnchor).isActive = true
        self.mainView.rightAnchor.constraint(equalTo: self.rightAnchor).isActive = true
    }
    
    private func setupConstraintsBtnReset() {
        self.btnReset.topAnchor.constraint(equalTo: self.btnReset.superview!.topAnchor).isActive = true
        self.btnReset.leftAnchor.constraint(equalTo: self.btnReset.superview!.leftAnchor).isActive = true
        self.btnReset.heightAnchor.constraint(equalToConstant: 40).isActive = true
        self.btnReset.widthAnchor.constraint(equalToConstant: 40).isActive = true
    }
    
    private func setupConstraintsLblDayString() {
        self.lblDayString.bottomAnchor.constraint(equalTo: self.gradientBottumView.topAnchor, constant: -30).isActive = true
        self.lblDayString.centerXAnchor.constraint(equalTo: self.lblDayString.superview!.centerXAnchor).isActive = true
    }
    
    private func setupConstraintsGradientBottumView() {
        self.gradientBottumView.bottomAnchor.constraint(equalTo: self.gradientBottumView.superview!.bottomAnchor).isActive = true
        self.gradientBottumView.leftAnchor.constraint(equalTo: self.gradientBottumView.superview!.leftAnchor).isActive = true
        self.gradientBottumView.rightAnchor.constraint(equalTo: self.gradientBottumView.superview!.rightAnchor).isActive = true
        self.gradientBottumView.heightAnchor.constraint(equalTo: self.gradientBottumView.superview!.heightAnchor, multiplier: 0.5).isActive = true
    }
    
    private func setupConstraintsLblMonthAndYear() {
        self.lblMonthAndYear.topAnchor.constraint(greaterThanOrEqualTo: self.lblMonthAndYear.superview!.topAnchor, constant: 8).isActive = true
        self.lblMonthAndYear.bottomAnchor.constraint(greaterThanOrEqualTo: self.lblMonthAndYear.superview!.bottomAnchor, constant: -8).isActive = true
        self.lblMonthAndYear.centerYAnchor.constraint(equalTo: self.lblMonthAndYear.superview!.centerYAnchor).isActive = true
        self.lblMonthAndYear.leftAnchor.constraint(equalTo: self.lblMonthAndYear.superview!.leftAnchor, constant: 16).isActive = true
        self.lblMonthAndYear.rightAnchor.constraint(equalTo: self.lblMonthAndYear.superview!.rightAnchor, constant: -16).isActive = true
    }
    
    private func setupConstraintsCalendarMainView() {
        self.calendarMainView.topAnchor.constraint(equalTo: self.calendarMainView.superview!.topAnchor).isActive = true
        self.calendarMainView.bottomAnchor.constraint(equalTo: self.calendarMainView.superview!.bottomAnchor).isActive = true
        self.calendarMainView.leftAnchor.constraint(equalTo: self.calendarMainView.superview!.leftAnchor).isActive = true
        self.calendarMainView.rightAnchor.constraint(equalTo: self.calendarMainView.superview!.rightAnchor).isActive = true
    }
    
    private func setupConstraintsCalendarCollectionView() {
        self.calendarCollectionView.topAnchor.constraint(equalTo: self.calendarCollectionView.superview!.topAnchor).isActive = true
        self.calendarCollectionView.bottomAnchor.constraint(equalTo: self.calendarCollectionView.superview!.bottomAnchor).isActive = true
        self.calendarCollectionView.leftAnchor.constraint(equalTo: self.calendarCollectionView.superview!.leftAnchor).isActive = true
        self.calendarCollectionView.rightAnchor.constraint(equalTo: self.calendarCollectionView.superview!.rightAnchor).isActive = true
    }
    
    private func setupConstraintsCalendarReloadIndicator() {
        self.calendarReloadIndicator.centerXAnchor.constraint(equalTo: self.calendarReloadIndicator.superview!.centerXAnchor).isActive = true
        self.calendarReloadIndicator.centerYAnchor.constraint(equalTo: self.lblDayString.centerYAnchor, constant: -40).isActive = true
        self.calendarReloadIndicator.heightAnchor.constraint(equalToConstant: 40).isActive = true
        self.calendarReloadIndicator.widthAnchor.constraint(equalToConstant: 40).isActive = true
    }
}

//MARK:- Calendar Stuff
extension CalendarView {
    
    private func setDefaultDate() {
        self.btnReset.isHidden = true
        self.isReloadToReset = true
        let dateFormator1 = DateFormatter()
        dateFormator1.dateFormat = "M"
        let month = Int(dateFormator1.string(from: Date()))
        self.currentDateMonthCount = month!
        dateFormator1.dateFormat = "YYYY"
        let year = Int(dateFormator1.string(from: Date()))
        self.currentDateYearCount = year!
        let dateFormator = DateFormatter()
        dateFormator.dateFormat = "d"
        let day = Int(dateFormator.string(from: Date()))
        self.currentDateDayCount = day!
        self.getCalendarData()
    }
    private func getCalendarData() {
        var monthsArr: [CalendarDateModel] = []
        var yearCount = self.currentDateYearCount - 1
        
        DispatchQueue.global(qos: .userInitiated).async {
            while yearCount <= self.currentDateYearCount + 1 {
                for monthCount in 1...12 {
                    for dayCount in 1...self.getNumDaysInMonthOfYear(Month: monthCount, inYear: yearCount) {
                        monthsArr.append(CalendarDateModel(Date: dayCount, inMonth: monthCount, fromYear: yearCount))
                    }
                }
                yearCount+=1
            }
            DispatchQueue.main.async {
                self.calendarDataArr = monthsArr
                self.calendarDatasource.setUpDatasourceForCalendar(withDatasource: self.calendarDataArr)
                self.calendarDelegate.delegate = self
                self.calendarDatasource.delegateDateSelection = self
                self.calendarCollectionView.dataSource = self.calendarDatasource
                self.calendarCollectionView.delegate = self.calendarDelegate
                let tupObj = CalendarDateModel(Date: self.currentDateDayCount, inMonth: self.currentDateMonthCount, fromYear: self.currentDateYearCount)
                var b = 0
                while b < self.calendarDataArr.count - 1 {
                    let item = self.calendarDataArr[b]
                    if "\(String(describing: item.year))-\(String(describing: item.month))-\(String(describing: item.date))" == "\(String(describing: tupObj.year))-\(String(describing: tupObj.month))-\(String(describing: tupObj.date))" {
                        self.currentCalIndex = b
                    }
                    b+=1
                }
                self.scrollToIndexCell(self.currentCalIndex)
            }
        }
    }
    private func getNumDaysInMonthOfYear(Month month: Int, inYear year: Int) -> Int {
        let dateComponents = DateComponents(year: year, month: month)
        let calendar = Calendar.current
        let date = calendar.date(from: dateComponents)!
        
        let range = calendar.range(of: .day, in: .month, for: date)!
        let numDays = range.count
        return numDays
    }
    
    /**
     This method is use for the scrolling the home dial calendar collectionview to perticular index.
     - Authors:
     - Created By - Bhavik Barot
     - Modified By - Bhavik Barot
     - Date:
     - Created At - 10/10/2018
     - Modified At - date
     - Version: 1.0
     - Remark:
     */
    private func scrollToIndexCell(_ indexForCell: Int) {
        self.calendarReloadIndicator.isHidden = false
        self.lblMonthAndYear.isHidden = true
        self.lblDayString.isHidden = true
        self.calendarReloadIndicator.startAnimating()
        self.calendarCollectionView.isHidden = true
        self.calendarCollectionView.reloadData()
        self.calendarCollectionView.contentOffset = CGPoint(x: 0, y: 0)
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(0), execute: {
            for _ in 0...indexForCell - 1 {
                self.scrollToNextCell()
            }
        })
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
            let cellArr = self.getVisibleCells()
            self.setupTheDialScrollSetting(CellArray: cellArr, IsContinue: false)
            self.calendarCollectionView.isHidden = false
            self.calendarReloadIndicator.stopAnimating()
            self.calendarReloadIndicator.isHidden = true
            self.lblMonthAndYear.isHidden = false
            self.lblDayString.isHidden = false
            self.isReloadToReset = false
        })
    }
    private func scrollToNextCell() {
        self.calendarCollectionView.layoutIfNeeded()
        self.calendarCollectionView.layoutSubviews()
        var cellSize: CGSize! {
            if UIScreen.main.bounds.width == 320 {
                return CGSize(width: 50, height: 50)
            }
            else if UIScreen.main.bounds.width == 414 {
                return CGSize(width: 80, height: 85)
            }
            else if UIScreen.main.bounds.width == 375 {
                return CGSize(width: 70, height: 70)
            }
            else {
                return CGSize(width: 70, height: 70)
            }
        }
        let contentOffset = self.calendarCollectionView.contentOffset
        self.calendarCollectionView.contentOffset = CGPoint(x: CGFloat(contentOffset.x + cellSize.width), y: contentOffset.y)
    }
    private func getVisibleCells() -> [(item: Int,cell: CalendarCollectionViewCell)] {
        var cellArr: [(item: Int,cell: CalendarCollectionViewCell)] = []
        for cell in self.calendarCollectionView.visibleCells {
            let cell = cell as! CalendarCollectionViewCell
            let indexpath: IndexPath = self.calendarCollectionView.indexPath(for: cell)!
            cellArr.append((indexpath.item,cell))
        }
        return cellArr
    }
    
    private func getSelectedDate() -> String {
        let cellArr = self.getVisibleCells()
        var cellArrNew = cellArr
        cellArrNew.sort(by: {$0.item < $1.item})
        let currentCalIndexPathCount = cellArrNew[2].item
        let selectedDate = self.calendarDataArr[currentCalIndexPathCount]
        return "\(selectedDate.date ?? 01)-\(selectedDate.month ?? 01)-\(selectedDate.year ?? 2000)"
    }
    
    private func setupTheDialScrollSetting(CellArray cellArr: [(item: Int,cell: CalendarCollectionViewCell)], IsContinue isContinue: Bool) {
        if isContinue {
            
            var cellArrNew = cellArr
            cellArrNew.sort(by: {$0.item < $1.item})
            var i = 0
            
            for item in cellArrNew {
                let cell = item.cell
                switch i {
                case 0: cell.lblDate.transform = CGAffineTransform(rotationAngle: CGFloat(100).degreesToRadians)
                self.setupFontsForCal(DateLabel: cell.lblDate, IsCurrent: false)
                case 1: cell.lblDate.transform = CGAffineTransform(rotationAngle: CGFloat(50).degreesToRadians)
                self.setupFontsForCal(DateLabel: cell.lblDate, IsCurrent: false)
                case 2: cell.lblDate.transform = CGAffineTransform(rotationAngle: CGFloat(0).degreesToRadians)
                self.setupFontsForCal(DateLabel: cell.lblDate, IsCurrent: true)
                let currDate = calendarDataArr[item.item]
                
                let dateFormater = DateFormatter()
                dateFormater.dateFormat = "YYYY-M-d"
                let curDate = dateFormater.date(from: "\(currDate.year ?? self.currentDateYearCount)-\(currDate.month ?? self.currentDateMonthCount)-\(currDate.date ?? self.currentDateDayCount)")
                
                if "\(currDate.year ?? self.currentDateYearCount)-\(currDate.month ?? self.currentDateMonthCount)-\(currDate.date ?? self.currentDateDayCount)" == dateFormater.string(from: Date()) {
                    self.btnReset.isHidden = true
                }
                else {
                    self.btnReset.isHidden = false
                }
                dateFormater.dateFormat = "MMM, yyyy"
                self.lblMonthAndYear.text = dateFormater.string(from: curDate!)
                dateFormater.dateFormat = "EEEE"
                self.lblDayString.text = dateFormater.string(from: curDate!)
                    
                case 3: cell.lblDate.transform = CGAffineTransform(rotationAngle: CGFloat(-50).degreesToRadians)
                self.setupFontsForCal(DateLabel: cell.lblDate, IsCurrent: false)
                case 4: cell.lblDate.transform = CGAffineTransform(rotationAngle: CGFloat(-100).degreesToRadians)
                self.setupFontsForCal(DateLabel: cell.lblDate, IsCurrent: false)
                default: cell.lblDate.transform = CGAffineTransform(rotationAngle: CGFloat(-100).degreesToRadians)
                self.setupFontsForCal(DateLabel: cell.lblDate, IsCurrent: false)
                }
                i += 1
            }
        }
        else {
            var cellArrNew = cellArr
            cellArrNew.sort(by: {$0.item < $1.item})
            var i = 0
            
            for item in cellArrNew {
                let cell = item.cell
                switch i {
                case 0: cell.lblDate.transform = CGAffineTransform(rotationAngle: CGFloat(100).degreesToRadians)
                self.setupFontsForCal(DateLabel: cell.lblDate, IsCurrent: false)
                case 1: cell.lblDate.transform = CGAffineTransform(rotationAngle: CGFloat(50).degreesToRadians)
                self.setupFontsForCal(DateLabel: cell.lblDate, IsCurrent: false)
                case 2: cell.lblDate.transform = CGAffineTransform(rotationAngle: CGFloat(0).degreesToRadians)
                self.setupFontsForCal(DateLabel: cell.lblDate, IsCurrent: true)
                case 3: cell.lblDate.transform = CGAffineTransform(rotationAngle: CGFloat(-50).degreesToRadians)
                self.setupFontsForCal(DateLabel: cell.lblDate, IsCurrent: false)
                case 4: cell.lblDate.transform = CGAffineTransform(rotationAngle: CGFloat(-100).degreesToRadians)
                self.setupFontsForCal(DateLabel: cell.lblDate, IsCurrent: false)
                default: cell.lblDate.transform = CGAffineTransform(rotationAngle: CGFloat(-100).degreesToRadians)
                self.setupFontsForCal(DateLabel: cell.lblDate, IsCurrent: false)
                }
                i += 1
            }
        }
    }
    private func setupFontsForCal(DateLabel label: UILabel, IsCurrent isCurrent: Bool) {
        if isCurrent {
            var font: UIFont! {
                if UIScreen.main.bounds.width == 320 {
                    return UIFont.boldSystemFont(ofSize: 38.0)
                }
                else if UIScreen.main.bounds.width == 414 {
                    return UIFont.boldSystemFont(ofSize: 58.0)
                }
                else if UIScreen.main.bounds.width == 375 {
                    return UIFont.boldSystemFont(ofSize: 52.0)
                }
                else {
                    return UIFont.boldSystemFont(ofSize: 52.0)
                }
            }
            label.font = font
        }
        else {
            var font: UIFont! {
                if UIScreen.main.bounds.width == 320 {
                    return UIFont.systemFont(ofSize: 18.0, weight: .medium)
                }
                else if UIScreen.main.bounds.width == 414 {
                    return UIFont.systemFont(ofSize: 25.0, weight: .medium)
                }
                else if UIScreen.main.bounds.width == 375 {
                    return UIFont.systemFont(ofSize: 21.0, weight: .medium)
                }
                else {
                    return UIFont.systemFont(ofSize: 21.0, weight: .medium)
                }
            }
            label.font = font
        }
        
        var dayCountFont: UIFont! {
            if UIScreen.main.bounds.width == 320 {
                return UIFont.systemFont(ofSize: 15)
            }
            else if UIScreen.main.bounds.width == 414 {
                return UIFont.systemFont(ofSize: 22)
            }
            else if UIScreen.main.bounds.width == 375 {
                return UIFont.systemFont(ofSize: 20)
            }
            else {
                return UIFont.systemFont(ofSize: 20)
            }
        }
        var monthFont: UIFont! {
            if UIScreen.main.bounds.width == 320 {
                return UIFont.boldSystemFont(ofSize: 17)
            }
            else if UIScreen.main.bounds.width == 414 {
                return UIFont.boldSystemFont(ofSize: 25)
            }
            else if UIScreen.main.bounds.width == 375 {
                return UIFont.boldSystemFont(ofSize: 22)
            }
            else {
                return UIFont.boldSystemFont(ofSize: 22)
            }
        }
        var msgFont: UIFont! {
            if UIScreen.main.bounds.width == 320 {
                return UIFont.systemFont(ofSize: 11)
            }
            else if UIScreen.main.bounds.width == 414 {
                return UIFont.systemFont(ofSize: 15)
            }
            else if UIScreen.main.bounds.width == 375 {
                return UIFont.systemFont(ofSize: 11)
            }
            else {
                return UIFont.systemFont(ofSize: 11)
            }
        }
        self.lblMonthAndYear.font = monthFont
        self.lblDayString.font = dayCountFont
    }
}

//MARK:- CollectionView Delegate and Datasource.
extension CalendarView: DelegateForCalendarView, DataSourceForCalendarView {
    
    func scrollViewDidScrollCustom(_ scrollView: UIScrollView) {
        if self.isReloadToReset {
            scrollView.contentOffset = CollectionViewPagging.shared.setContentOffset(forProposedContentOffset: scrollView.contentOffset, withScrollingVelocity: CGPoint(x: 0, y: 0), collectionView: self.calendarCollectionView)
            scrollView.layoutIfNeeded()
        }
        self.btnReset.isEnabled = false
        let cellArr = self.getVisibleCells()
        self.setupTheDialScrollSetting(CellArray: cellArr, IsContinue: true)
        
        if self.delegate != nil {
            self.delegate?.didScrollCalendarView(scrollView)
        }
    }
    func scrollViewDidEndDeceleratingCustom(_ scrollView: UIScrollView) {
        self.btnReset.isEnabled = true
        self.isReloadToReset = false
        let cellArr = self.getVisibleCells()
        self.setupTheDialScrollSetting(CellArray: cellArr, IsContinue: false)
        
        if self.delegate != nil {
            self.delegate?.calendarViewDidEndDecelerating(scrollView)
        }
    }
    
    func didTapOnMiddleDate(_ sender: UIButton) {
        let selectedDate = self.calendarDataArr[sender.tag]
        if self.delegate != nil {
            self.delegate?.didTapDateOnCenter(self, With: "\(selectedDate.date ?? 01)-\(selectedDate.month ?? 01)-\(selectedDate.year ?? 2000)")
        }
    }
}
extension FloatingPoint {
    var degreesToRadians: Self { return self * .pi / 180 }
    var radiansToDegrees: Self { return self * 180 / .pi }
}
