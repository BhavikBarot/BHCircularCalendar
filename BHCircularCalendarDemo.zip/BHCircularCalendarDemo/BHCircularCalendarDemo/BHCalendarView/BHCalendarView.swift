//
//  BHCalendarView.swift
//  BHCircularCalendar
//
//  Created by Bhavik's Mac on 27/02/19.
//  Copyright © 2019 Bhavik Barot. All rights reserved.
//

import UIKit

@IBDesignable
class BHCalendarView: UIView {
    
    private var bhCalendar = BHCircularCalendar()
    public var delegate: BHCalendarDelegate? {
        willSet {
            self.bhCalendar.delegate = newValue
        }
    }
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .clear
    }
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func draw(_ rect: CGRect) {
//        self.setupConstraintsForSelf()
        self.bhCalendar.frame = rect
        self.insertSubview(self.bhCalendar, at: 0)
    }
}

extension BHCalendarView {
    private func setupConstraintsForSelf() {
        self.translatesAutoresizingMaskIntoConstraints = false
        self.widthAnchor.constraint(equalToConstant: 295)
        self.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1).isActive = true
//        self.topAnchor.constraint(equalTo: self.superview!.topAnchor).isActive = true
//        self.bottomAnchor.constraint(equalTo: self.superview!.bottomAnchor).isActive = true
//        self.leftAnchor.constraint(equalTo: self.superview!.leftAnchor).isActive = true
//        self.rightAnchor.constraint(equalTo: self.superview!.rightAnchor).isActive = true
    }
}

//MARK:- Main View Property Setup
extension BHCalendarView {
    var calendarBackgroundColor: UIColor! {
        set {
            self.bhCalendar.calendarBackgroundColor = newValue
        }
        get {
            return self.bhCalendar.calendarBackgroundColor
        }
    }
}

//MARK:- Gradient View Property Setup
extension BHCalendarView {
    var bottomViewBackgroundColor: UIColor! {
        set {
            self.bhCalendar.bottomViewBackgroundColor = newValue
        }
        get {
            return self.bhCalendar.bottomViewBackgroundColor
        }
    }
    
    var bottomViewCornerRedius: CGFloat! {
        set {
            self.bhCalendar.bottomViewCornerRedius = newValue
        }
        get {
            return self.bhCalendar.bottomViewCornerRedius
        }
    }
    
    var gradientForBottumView: CAGradientLayer {
        set {
            self.bhCalendar.gradientForBottumView = newValue
        }
        get {
            return self.bhCalendar.gradientForBottumView
        }
    }
}

//MARK:- Reset Button Property Setup
extension BHCalendarView {
    var resetButtonBackgroundColor: UIColor! {
        set {
            self.bhCalendar.resetButtonBackgroundColor = newValue
        }
        get {
            return self.bhCalendar.resetButtonBackgroundColor
        }
    }
    
    var resetButtonBackgroundImage: UIImage? {
        set {
            self.bhCalendar.resetButtonBackgroundImage = newValue
        }
        get {
            return self.bhCalendar.resetButtonBackgroundImage
        }
    }
    
    var resetButtonTitle: String! {
        set {
            self.bhCalendar.resetButtonTitle = newValue
        }
        get {
            return self.bhCalendar.resetButtonTitle
        }
    }
    
    var resetButtonTitleForNormalState: String! {
        set {
            self.bhCalendar.resetButtonTitleForNormalState = newValue
        }
        get {
            return self.bhCalendar.resetButtonTitleForNormalState
        }
    }
    
    var resetButtonTitleForSelectedState: String! {
        set {
            self.bhCalendar.resetButtonTitleForSelectedState = newValue
        }
        get {
            return self.bhCalendar.resetButtonTitleForSelectedState
        }
    }
}

//MARK:- Month and Year Label Property Setup
extension BHCalendarView {
    
    var infoLabelText: String! {
        set {
            self.bhCalendar.infoLabelText = newValue
        }
        get {
            return self.bhCalendar.infoLabelText
        }
    }
    
    var infoLabelTextColor: UIColor! {
        set {
            self.bhCalendar.infoLabelTextColor = newValue
        }
        get {
            return self.bhCalendar.infoLabelTextColor
        }
    }
    
    var infoLabelTextAlignment: NSTextAlignment! {
        set {
            self.bhCalendar.infoLabelTextAlignment = newValue
        }
        get {
            return self.bhCalendar.infoLabelTextAlignment
        }
    }
}

//MARK:- Day Label Property Setup
extension BHCalendarView {
    
    var dayFormatForCalendar: String! {
        set {
            self.bhCalendar.dayFormatForCalendar = newValue
        }
        get {
            return self.bhCalendar.dayFormatForCalendar
        }
    }
    
    var dayLabelTextColor: UIColor! {
        set {
            self.bhCalendar.dayLabelTextColor = newValue
        }
        get {
            return self.bhCalendar.dayLabelTextColor
        }
    }
    
    var dayLabelTextAlignment: NSTextAlignment! {
        set {
            self.bhCalendar.dayLabelTextAlignment = newValue
        }
        get {
            return self.bhCalendar.dayLabelTextAlignment
        }
    }
}

//MARK:- Extra Property
extension BHCalendarView {
    var getCurrentSelectedDate: String! {
        get {
            return self.bhCalendar.getCurrentSelectedDate
        }
    }
}
