//
//  BHCalendarView.swift
//  BHCircularCalendar
//
//  Created by Bhavik's Mac on 27/02/19.
//  Copyright © 2019 Bhavik Barot. All rights reserved.
//

import UIKit

@IBDesignable
class BHCalendarView: UIView {
    
    private var calendarView = CalendarView()
    public var delegate: BHCalendarDelegate? {
        willSet {
            self.calendarView.delegate = newValue
        }
    }
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .clear
    }
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func draw(_ rect: CGRect) {
        self.setupConstraintsForSelf()
        self.calendarView.frame = rect
        self.insertSubview(self.calendarView, at: 0)
    }
}

extension BHCalendarView {
    private func setupConstraintsForSelf() {
        self.translatesAutoresizingMaskIntoConstraints = false
        self.widthAnchor.constraint(equalToConstant: 295)
        self.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1).isActive = true
//        self.topAnchor.constraint(equalTo: self.superview!.topAnchor).isActive = true
//        self.bottomAnchor.constraint(equalTo: self.superview!.bottomAnchor).isActive = true
//        self.leftAnchor.constraint(equalTo: self.superview!.leftAnchor).isActive = true
//        self.rightAnchor.constraint(equalTo: self.superview!.rightAnchor).isActive = true
    }
}

//MARK:- Main View Property Setup
extension BHCalendarView {
    var calendarBackgroundColor: UIColor! {
        set {
            self.calendarView.calendarBackgroundColor = newValue
        }
        get {
            return self.calendarView.calendarBackgroundColor
        }
    }
}

//MARK:- Gradient View Property Setup
extension BHCalendarView {
    var bottomViewBackgroundColor: UIColor! {
        set {
            self.calendarView.bottomViewBackgroundColor = newValue
        }
        get {
            return self.calendarView.bottomViewBackgroundColor
        }
    }
    
    var bottomViewCornerRedius: CGFloat! {
        set {
            self.calendarView.bottomViewCornerRedius = newValue
        }
        get {
            return self.calendarView.bottomViewCornerRedius
        }
    }
    
    var gradientForBottumView: CAGradientLayer {
        set {
            self.calendarView.gradientForBottumView = newValue
        }
        get {
            return self.calendarView.gradientForBottumView
        }
    }
}

//MARK:- Reset Button Property Setup
extension BHCalendarView {
    var resetButtonBackgroundColor: UIColor! {
        set {
            self.calendarView.resetButtonBackgroundColor = newValue
        }
        get {
            return self.calendarView.resetButtonBackgroundColor
        }
    }
    
    var resetButtonBackgroundImage: UIImage? {
        set {
            self.calendarView.resetButtonBackgroundImage = newValue
        }
        get {
            return self.calendarView.resetButtonBackgroundImage
        }
    }
    
    var resetButtonTitle: String! {
        set {
            self.calendarView.resetButtonTitle = newValue
        }
        get {
            return self.calendarView.resetButtonTitle
        }
    }
    
    var resetButtonTitleForNormalState: String! {
        set {
            self.calendarView.resetButtonTitleForNormalState = newValue
        }
        get {
            return self.calendarView.resetButtonTitleForNormalState
        }
    }
    
    var resetButtonTitleForSelectedState: String! {
        set {
            self.calendarView.resetButtonTitleForSelectedState = newValue
        }
        get {
            return self.calendarView.resetButtonTitleForSelectedState
        }
    }
}

//MARK:- Month and Year Label Property Setup
extension BHCalendarView {
    var infoLabelTextColor: UIColor! {
        set {
            self.calendarView.infoLabelTextColor = newValue
        }
        get {
            return self.calendarView.infoLabelTextColor
        }
    }
    
    var infoLabelTextAlignment: NSTextAlignment! {
        set {
            self.calendarView.infoLabelTextAlignment = newValue
        }
        get {
            return self.calendarView.infoLabelTextAlignment
        }
    }
}

//MARK:- Day Label Property Setup
extension BHCalendarView {
    var dayLabelTextColor: UIColor! {
        set {
            self.calendarView.dayLabelTextColor = newValue
        }
        get {
            return self.calendarView.dayLabelTextColor
        }
    }
    
    var dayLabelTextAlignment: NSTextAlignment! {
        set {
            self.calendarView.dayLabelTextAlignment = newValue
        }
        get {
            return self.calendarView.dayLabelTextAlignment
        }
    }
}

//MARK:- Extra Property
extension BHCalendarView {
    var getCurrentSelectedDate: String! {
        get {
            return self.calendarView.getCurrentSelectedDate
        }
    }
}
