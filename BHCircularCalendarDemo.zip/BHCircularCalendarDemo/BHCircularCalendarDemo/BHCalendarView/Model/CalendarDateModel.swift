//
//  CalendarDateModel.swift
//  CirculerCalendarDemo
//
//  Created by Bhavik's Mac on 31/10/18.
//  Copyright © 2018 Bhavik Barot. All rights reserved.
//

import UIKit

class CalendarDateModel: NSObject {
    public var date: Int?
    public var month: Int?
    public var year: Int?
    
    init(Date date: Int?, inMonth month: Int?, fromYear year: Int?) {
        self.date = date
        self.month = month
        self.year = year
    }
    required convenience init(coder aDecoder: NSCoder) {
        let date = aDecoder.decodeObject(forKey: "date") as! Int
        let month = aDecoder.decodeObject(forKey: "month") as! Int
        let year = aDecoder.decodeObject(forKey: "year") as! Int
        self.init(Date: date, inMonth: month, fromYear: year)
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(date, forKey: "date")
        aCoder.encode(month, forKey: "month")
        aCoder.encode(year, forKey: "year")
    }
}
