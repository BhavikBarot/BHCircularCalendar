//
//  BHCalendarDelegate.swift
//  BHCircularCalendar
//
//  Created by Bhavik's Mac on 28/02/19.
//  Copyright © 2019 Bhavik Barot. All rights reserved.
//

import UIKit

protocol BHCalendarDelegate: class {
    func resetButtonClicked(_ sender: UIButton)
    func didScrollCalendarView(_ scrollView: UIScrollView)
    func calendarViewDidEndDecelerating(_ scrollView: UIScrollView)
    func didTapDateOnCenter(_ calendarView: CalendarView, With date: String)
}
extension BHCalendarDelegate {
    func resetButtonClicked(_ sender: UIButton) {}
    func didScrollCalendarView(_ scrollView: UIScrollView) {}
    func calendarViewDidEndDecelerating(_ scrollView: UIScrollView) {}
    func didTapDateOnCenter(_ calendarView: CalendarView, With date: String) {}
}
