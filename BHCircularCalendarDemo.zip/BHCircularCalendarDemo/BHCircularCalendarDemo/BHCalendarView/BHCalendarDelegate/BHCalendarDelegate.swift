//
//  BHCalendarDelegate.swift
//  BHCircularCalendar
//
//  Created by Bhavik's Mac on 28/02/19.
//  Copyright © 2019 Bhavik Barot. All rights reserved.
//

import UIKit

protocol BHCalendarDelegate: class {
    func resetButtonClicked(_ sender: UIButton)
    func didScrollCalendarView(_ scrollView: UIScrollView)
    func calendarViewDidEndDecelerating(_ scrollView: UIScrollView)
    func didTapDateOnCenter(_ calendarView: BHCircularCalendar, With date: String)
    func willDisplayCellWithDate(_ calendarView: BHCircularCalendar, Cell cell: BHCalendarCell, With date: String)
    func willDisplayCenterCellWithDate(_ calendarView: BHCircularCalendar, Cell cell: BHCalendarCell, With date: String)
    func visibleCellsAtEndOfScroll(_ calendarView: BHCircularCalendar, With cells: [BHCalendarCell])
    func visibleDatesAtEndOfScroll(_ calendarView: BHCircularCalendar, With dates: [String])
}
extension BHCalendarDelegate {
    func resetButtonClicked(_ sender: UIButton) {}
    func didScrollCalendarView(_ scrollView: UIScrollView) {}
    func calendarViewDidEndDecelerating(_ scrollView: UIScrollView) {}
    func didTapDateOnCenter(_ calendarView: BHCircularCalendar, With date: String) {}
    func visibleCellsAtEndOfScroll(_ calendarView: BHCircularCalendar, With cells: [BHCalendarCell]) {}
    func visibleDatesAtEndOfScroll(_ calendarView: BHCircularCalendar, With dates: [String]) {}
    func willDisplayCellWithDate(_ calendarView: BHCircularCalendar, Cell cell: BHCalendarCell, With date: String) {}
    func willDisplayCenterCellWithDate(_ calendarView: BHCircularCalendar, Cell cell: BHCalendarCell, With date: String) {}
}
