//
//  CollectionViewPagging.swift
//  BHCircularCalendarDemo
//
//  Created by Bhavik's Mac on 31/01/19.
//  Copyright © 2019 Bhavik Barot. All rights reserved.
//

import UIKit

class CollectionViewPagging: NSObject {
    public static let shared: CollectionViewPagging = {
        return CollectionViewPagging()
    }()
    
    open func setContentOffset(forProposedContentOffset proposedContentOffset: CGPoint, withScrollingVelocity velocity: CGPoint, collectionView: UICollectionView) -> CGPoint {
        let point = targetContentOffset(forProposedContentOffset: proposedContentOffset, withScrollingVelocity: velocity, collectionView: collectionView)
        return point
    }
    
    private func targetContentOffset(forProposedContentOffset proposedContentOffset: CGPoint, withScrollingVelocity velocity: CGPoint, collectionView: UICollectionView) -> CGPoint {
        let anglePerItem: CGFloat = 0.90
        var angleAtExtreme: CGFloat {
            return collectionView.numberOfItems(inSection: 0) > 0 ?
                -CGFloat(collectionView.numberOfItems(inSection: 0) - 1) * anglePerItem : 0
        }
        
        var itemSize: CGSize! {
            if UIScreen.main.bounds.width == 320 {
                return CGSize(width: 50, height: 50)
            }
            else if UIScreen.main.bounds.width == 414 {
                return CGSize(width: 80, height: 85)
            }
            else if UIScreen.main.bounds.width == 375 {
                return CGSize(width: 70, height: 70)
            }
            else {
                return CGSize(width: 70, height: 70)
            }
        }
        
        var collectionViewContentSize: CGSize {
            return CGSize(width: CGFloat(collectionView.numberOfItems(inSection: 0)) * itemSize.width, height: collectionView.bounds.height)
        }
        
        var finalContentOffset = proposedContentOffset
        let factor = -angleAtExtreme/(collectionViewContentSize.width -
            collectionView.bounds.width)
        let proposedAngle = proposedContentOffset.x*factor
        let ratio = proposedAngle/anglePerItem
        var multiplier: CGFloat
        if (velocity.x > 0) {
            multiplier = ceil(ratio)
        } else if (velocity.x < 0) {
            multiplier = floor(ratio)
        } else {
            multiplier = round(ratio)
        }
        finalContentOffset.x = multiplier*anglePerItem/factor
        return finalContentOffset
    }
}
