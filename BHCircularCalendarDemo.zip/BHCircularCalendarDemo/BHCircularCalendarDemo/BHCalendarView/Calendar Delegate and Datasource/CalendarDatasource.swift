//
//  CalendarDatasource.swift
//  CirculerCalendarDemo
//
//  Created by Bhavik's Mac on 31/10/18.
//  Copyright © 2018 Bhavik Barot. All rights reserved.
//

import UIKit
import Foundation

protocol DataSourceForCalendarView: class {
    func didTapOnMiddleDate(_ sender: UIButton)
}

class CalendarDatasource: NSObject, UICollectionViewDataSource {
    var dataSourceArray:[CalendarDateModel] = []
    weak var delegateDateSelection: DataSourceForCalendarView?
    
    func setUpDatasourceForCalendar(withDatasource datasource: [CalendarDateModel]) {
        self.dataSourceArray = datasource
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if dataSourceArray.count == 0 {
            return 1
        }
        else {
            return dataSourceArray.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CalendarCollectionViewCell", for: indexPath) as! CalendarCollectionViewCell
        if dataSourceArray.count == 0 {
            cell.lblDate.text = ""
        }
        else {
            let dateForLabel = dataSourceArray[indexPath.row]
            cell.lblDate.text = "\(dateForLabel.date ?? 01)"
            cell.btnSelection.tag = indexPath.row
            cell.btnSelection.addTarget(self, action: #selector(self.dateSelectionSEL(_:)), for: .touchUpInside)
        }
        return cell
    }
}
extension CalendarDatasource {
    @objc private func dateSelectionSEL(_ sender: UIButton) {
        if self.delegateDateSelection != nil {
            self.delegateDateSelection?.didTapOnMiddleDate(sender)
        }
    }
}
