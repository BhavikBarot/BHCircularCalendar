//
//  CalendarDelegate.swift
//  BHCircularCalendarDemo
//
//  Created by Bhavik's Mac on 31/10/18.
//  Copyright © 2018 Bhavik Barot. All rights reserved.
//

import UIKit
protocol DelegateForCalendarView: class {
    func scrollViewDidScrollCustom(_ scrollView: UIScrollView)
    func scrollViewDidEndDeceleratingCustom(_ scrollView: UIScrollView)
    func collectionViewCustom(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath)
}
class CalendarDelegate: NSObject, UICollectionViewDelegate, UIScrollViewDelegate {
    
    weak var delegate: DelegateForCalendarView?
    
    //MARK:- ScrollViewDelegates
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if self.delegate != nil {
            self.delegate?.scrollViewDidScrollCustom(scrollView)
        }
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        if self.delegate != nil {
            self.delegate?.scrollViewDidEndDeceleratingCustom(scrollView)
        }
    }
    
    //MARK:- CollectionViewDelegates
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        if self.delegate != nil {
            self.delegate?.collectionViewCustom(collectionView, willDisplay: cell, forItemAt: indexPath)
        }
    }
}
