//
//  CalendarDelegate.swift
//  CirculerCalendarDemo
//
//  Created by Bhavik's Mac on 31/10/18.
//  Copyright © 2018 Bhavik Barot. All rights reserved.
//

import UIKit
protocol DelegateForCalendarView: class {
    func scrollViewDidScrollCustom(_ scrollView: UIScrollView)
    func scrollViewDidEndDeceleratingCustom(_ scrollView: UIScrollView)
}
class CalendarDelegate: NSObject, UICollectionViewDelegate, UIScrollViewDelegate {
    
    weak var delegate: DelegateForCalendarView?
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if self.delegate != nil {
            self.delegate?.scrollViewDidScrollCustom(scrollView)
        }
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        if self.delegate != nil {
            self.delegate?.scrollViewDidEndDeceleratingCustom(scrollView)
        }
    }
}
