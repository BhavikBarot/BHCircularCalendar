//
//  ViewController.swift
//  BHCircularCalendarDemo
//
//  Created by Bhavik's Mac on 31/10/18.
//  Copyright © 2018 Bhavik Barot. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var calView: BHCalendarView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.calView.delegate = self
        self.calView.dayFormatForCalendar = "EEE-MMM"
        self.calView.infoLabelText = "Hello"
    }
}
extension ViewController: BHCalendarDelegate {
    func didTapDateOnCenter(_ calendarView: BHCircularCalendar, With date: String) {
        print("+++\(date)+++")
    }
    
    func resetButtonClicked(_ sender: UIButton) {
        print("+++Calendar is Reset+++")
    }
    
    func visibleDatesAtEndOfScroll(_ calendarView: BHCircularCalendar, With dates: [String]) {
        print("+++\(dates)+++")
    }
    
    func willDisplayCellWithDate(_ calendarView: BHCircularCalendar, Cell cell: BHCalendarCell, With date: String) {
        if Formatter.iso8601.string(from: Formatter.calendarDateFormattor.date(from: date)!) == Date().iso8601 {
            cell.lblDate.textColor = .red
        }
        else {
            cell.lblDate.textColor = .white
        }
    }
}
