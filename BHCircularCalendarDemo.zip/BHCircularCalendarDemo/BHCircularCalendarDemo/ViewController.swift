//
//  ViewController.swift
//  CirculerCalendarDemo
//
//  Created by Bhavik's Mac on 31/10/18.
//  Copyright © 2018 Bhavik Barot. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var calView: BHCalendarView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.calView.delegate = self
    }
}
extension ViewController: BHCalendarDelegate {
    func didTapDateOnCenter(_ calendarView: CalendarView, With date: String) {
        print("+++\(date)+++")
    }
    
    func resetButtonClicked(_ sender: UIButton) {
        print("+++Calendar is Reset+++")
    }
}
