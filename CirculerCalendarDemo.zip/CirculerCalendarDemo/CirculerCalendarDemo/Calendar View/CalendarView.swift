//
//  CalendarView.swift
//  CirculerCalendarDemo
//
//  Created by Bhavik's Mac on 31/10/18.
//  Copyright © 2018 Bhavik Barot. All rights reserved.
//

import UIKit
import Foundation

class CalendarView: UIView {
    
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var btnReset: UIButton!
    @IBOutlet weak var lblMonthAndYear: UILabel!
    @IBOutlet weak var lblDayString: UILabel!
    @IBOutlet weak var gradientBottumView: UIView!
    @IBOutlet weak var calendarMainView: UIView!
    @IBOutlet weak var calendarCollectionView: UICollectionView!
    @IBOutlet weak var calendarReloadIndicator: UIActivityIndicatorView!
    
    var isReloadToReset: Bool! = true
    var currentDateDayCount = Int()
    var currentDateMonthCount = Int()
    var currentDateYearCount = Int()
    var calendarDataArr:[CalendarDateModel] = []
    var currentCalIndex = Int()
    fileprivate let gregorian = Calendar(identifier: .gregorian)
    fileprivate let formatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }()
    lazy var calendarDatasource: CalendarDatasource = {
        let calendarDatasource = CalendarDatasource()
        return calendarDatasource
    }()
    lazy var calendarDelegate: CalendarDelegate = {
        let calendarDelegate = CalendarDelegate()
        return calendarDelegate
    }()
    
    override func awakeFromNib() {
        self.setupUI()
    }
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        
    }
    
    @IBAction func btnResetAction(_ sender: UIButton) {
        if btnReset.isEnabled {
            setDefaultDate()
        }
    }
    
    //MARK:- Private Methods.
    private func setupUI() {
        mainView.layoutIfNeeded()
        mainView.setNeedsLayout()
        mainView.layer.cornerRadius = mainView.bounds.size.width / 2
        
        calendarMainView.layoutIfNeeded()
        calendarMainView.setNeedsLayout()
        calendarMainView.layer.cornerRadius = calendarMainView.bounds.width / 2
        
        gradientBottumView.layoutIfNeeded()
        gradientBottumView.setNeedsLayout()
        gradientBottumView.layer.cornerRadius = mainView.bounds.size.width / 2
        
        calendarCollectionView.register(UINib(nibName: "CalendarCollectionViewCell", bundle: Bundle.main), forCellWithReuseIdentifier: "CalendarCollectionViewCell")
        
        self.setDefaultDate()
    }
    private func setDefaultDate() {
        btnReset.isHidden = true
        isReloadToReset = true
        let dateFormator1 = DateFormatter()
        dateFormator1.dateFormat = "M"
        let month = Int(dateFormator1.string(from: Date()))
        currentDateMonthCount = month!
        dateFormator1.dateFormat = "YYYY"
        let year = Int(dateFormator1.string(from: Date()))
        currentDateYearCount = year!
        let dateFormator = DateFormatter()
        dateFormator.dateFormat = "d"
        let day = Int(dateFormator.string(from: Date()))
        currentDateDayCount = day!
        getCalendarData()
    }
    private func getCalendarData() {
        var monthsArr: [CalendarDateModel] = []
        var yearCount = currentDateYearCount - 1
        
        DispatchQueue.global(qos: .userInitiated).async {
            while yearCount <= self.currentDateYearCount + 1 {
                for monthCount in 1...12 {
                    for dayCount in 1...self.getNumDaysInMonthOfYear(Month: monthCount, inYear: yearCount) {
                        monthsArr.append(CalendarDateModel(Date: dayCount, inMonth: monthCount, fromYear: yearCount))
                    }
                }
                yearCount+=1
            }
            DispatchQueue.main.async {
                self.calendarDataArr = monthsArr
                self.calendarDatasource.setUpDatasourceForCalendar(withDatasource: self.calendarDataArr)
                self.calendarDelegate.delegate = self
                self.calendarCollectionView.dataSource = self.calendarDatasource
                self.calendarCollectionView.delegate = self.calendarDelegate
                let tupObj = CalendarDateModel(Date: self.currentDateDayCount, inMonth: self.currentDateMonthCount, fromYear: self.currentDateYearCount)
                var b = 0
                while b < self.calendarDataArr.count - 1 {
                    let item = self.calendarDataArr[b]
                    if "\(String(describing: item.year))-\(String(describing: item.month))-\(String(describing: item.date))" == "\(String(describing: tupObj.year))-\(String(describing: tupObj.month))-\(String(describing: tupObj.date))" {
                        self.currentCalIndex = b
                    }
                    b+=1
                }
                self.scrollToIndexCell(self.currentCalIndex)
            }
        }
    }
    private func getNumDaysInMonthOfYear(Month month: Int, inYear year: Int) -> Int {
        let dateComponents = DateComponents(year: year, month: month)
        let calendar = Calendar.current
        let date = calendar.date(from: dateComponents)!
        
        let range = calendar.range(of: .day, in: .month, for: date)!
        let numDays = range.count
        return numDays
    }
    
    /**
     This method is use for the scrolling the home dial calendar collectionview to perticular index.
     - Authors:
     - Created By - Bhavik Barot
     - Modified By - Bhavik Barot
     - Date:
     - Created At - 10/10/2018
     - Modified At - date
     - Version: 1.0
     - Remark:
     */
    func scrollToIndexCell(_ indexForCell: Int) {
        self.calendarReloadIndicator.isHidden = false
        self.lblMonthAndYear.isHidden = true
        self.lblDayString.isHidden = true
        self.calendarReloadIndicator.startAnimating()
        self.calendarCollectionView.isHidden = true
        self.calendarCollectionView.reloadData()
        self.calendarCollectionView.contentOffset = CGPoint(x: 0, y: 0)
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(0), execute: {
            for _ in 0...indexForCell - 1 {
                self.scrollToNextCell()
            }
        })
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
            let cellArr = self.getVisibleCells()
            self.setupTheDialScrollSetting(CellArray: cellArr, IsContinue: false)
            self.calendarCollectionView.isHidden = false
            self.calendarReloadIndicator.stopAnimating()
            self.calendarReloadIndicator.isHidden = true
            self.lblMonthAndYear.isHidden = false
            self.lblDayString.isHidden = false
            self.isReloadToReset = false
        })
    }
    private func scrollToNextCell() {
        calendarCollectionView.layoutIfNeeded()
        calendarCollectionView.layoutSubviews()
        var cellSize: CGSize! {
            if UIScreen.main.bounds.width == 320 {
                return CGSize(width: 50, height: 50)
            }
            else if UIScreen.main.bounds.width == 414 {
                return CGSize(width: 80, height: 85)
            }
            else if UIScreen.main.bounds.width == 375 {
                return CGSize(width: 70, height: 70)
            }
            else {
                return CGSize(width: 70, height: 70)
            }
        }
        let contentOffset = calendarCollectionView.contentOffset
        calendarCollectionView.contentOffset = CGPoint(x: CGFloat(contentOffset.x + cellSize.width), y: contentOffset.y)
    }
    private func getVisibleCells() -> [(item: Int,cell: CalendarCollectionViewCell)] {
        var cellArr: [(item: Int,cell: CalendarCollectionViewCell)] = []
        for cell in calendarCollectionView.visibleCells {
            let cell = cell as! CalendarCollectionViewCell
            let indexpath: IndexPath = calendarCollectionView.indexPath(for: cell)!
            cellArr.append((indexpath.item,cell))
        }
        return cellArr
    }
    
    private func setupTheDialScrollSetting(CellArray cellArr: [(item: Int,cell: CalendarCollectionViewCell)], IsContinue isContinue: Bool) {
        if isContinue {
            
            var cellArrNew = cellArr
            cellArrNew.sort(by: {$0.item < $1.item})
            var i = 0
            
            for item in cellArrNew {
                let cell = item.cell
                switch i {
                case 0: cell.lblDate.transform = CGAffineTransform(rotationAngle: CGFloat(100).degreesToRadians)
                setupFontsForCal(DateLabel: cell.lblDate, IsCurrent: false)
                case 1: cell.lblDate.transform = CGAffineTransform(rotationAngle: CGFloat(50).degreesToRadians)
                setupFontsForCal(DateLabel: cell.lblDate, IsCurrent: false)
                case 2: cell.lblDate.transform = CGAffineTransform(rotationAngle: CGFloat(0).degreesToRadians)
                setupFontsForCal(DateLabel: cell.lblDate, IsCurrent: false)
                let currDate = calendarDataArr[item.item]
                
                let dateFormater = DateFormatter()
                dateFormater.dateFormat = "YYYY-M-d"
                let curDate = dateFormater.date(from: "\(currDate.year ?? self.currentDateYearCount)-\(currDate.month ?? self.currentDateMonthCount)-\(currDate.date ?? self.currentDateDayCount)")
                
                if "\(currDate.year ?? self.currentDateYearCount)-\(currDate.month ?? self.currentDateMonthCount)-\(currDate.date ?? self.currentDateDayCount)" == dateFormater.string(from: Date()) {
                    btnReset.isHidden = true
                }
                else {
                    btnReset.isHidden = false
                }
                dateFormater.dateFormat = "MMM, yyyy"
                lblMonthAndYear.text = dateFormater.string(from: curDate!)
                dateFormater.dateFormat = "EEEE"
                lblDayString.text = dateFormater.string(from: curDate!)
                    
                case 3: cell.lblDate.transform = CGAffineTransform(rotationAngle: CGFloat(-50).degreesToRadians)
                setupFontsForCal(DateLabel: cell.lblDate, IsCurrent: false)
                case 4: cell.lblDate.transform = CGAffineTransform(rotationAngle: CGFloat(-100).degreesToRadians)
                setupFontsForCal(DateLabel: cell.lblDate, IsCurrent: false)
                default: cell.lblDate.transform = CGAffineTransform(rotationAngle: CGFloat(-100).degreesToRadians)
                setupFontsForCal(DateLabel: cell.lblDate, IsCurrent: false)
                }
                i += 1
            }
        }
        else {
            var cellArrNew = cellArr
            cellArrNew.sort(by: {$0.item < $1.item})
            var i = 0
            
            for item in cellArrNew {
                let cell = item.cell
                switch i {
                case 0: cell.lblDate.transform = CGAffineTransform(rotationAngle: CGFloat(100).degreesToRadians)
                setupFontsForCal(DateLabel: cell.lblDate, IsCurrent: false)
                case 1: cell.lblDate.transform = CGAffineTransform(rotationAngle: CGFloat(50).degreesToRadians)
                setupFontsForCal(DateLabel: cell.lblDate, IsCurrent: false)
                case 2: cell.lblDate.transform = CGAffineTransform(rotationAngle: CGFloat(0).degreesToRadians)
                setupFontsForCal(DateLabel: cell.lblDate, IsCurrent: true)
                case 3: cell.lblDate.transform = CGAffineTransform(rotationAngle: CGFloat(-50).degreesToRadians)
                setupFontsForCal(DateLabel: cell.lblDate, IsCurrent: false)
                case 4: cell.lblDate.transform = CGAffineTransform(rotationAngle: CGFloat(-100).degreesToRadians)
                setupFontsForCal(DateLabel: cell.lblDate, IsCurrent: false)
                default: cell.lblDate.transform = CGAffineTransform(rotationAngle: CGFloat(-100).degreesToRadians)
                setupFontsForCal(DateLabel: cell.lblDate, IsCurrent: false)
                }
                i += 1
            }
        }
    }
    private func setupFontsForCal(DateLabel label: UILabel, IsCurrent isCurrent: Bool) {
        if isCurrent {
            var font: UIFont! {
                if UIScreen.main.bounds.width == 320 {
                    return UIFont(name: "Roboto-Bold", size: 38.0)
                }
                else if UIScreen.main.bounds.width == 414 {
                    return UIFont(name: "Roboto-Bold", size: 58.0)
                }
                else if UIScreen.main.bounds.width == 375 {
                    return UIFont(name: "Roboto-Bold", size: 52.0)
                }
                else {
                    return UIFont(name: "Roboto-Bold", size: 52.0)
                }
            }
            label.font = font
        }
        else {
            var font: UIFont! {
                if UIScreen.main.bounds.width == 320 {
                    return UIFont(name: "Roboto-Medium", size: 18.0)
                }
                else if UIScreen.main.bounds.width == 414 {
                    return UIFont(name: "Roboto-Medium", size: 25.0)
                }
                else if UIScreen.main.bounds.width == 375 {
                    return UIFont(name: "Roboto-Medium", size: 21.0)
                }
                else {
                    return UIFont(name: "Roboto-Medium", size: 21.0)
                }
            }
            label.font = font
        }
        
        var dayCountFont: UIFont! {
            if UIScreen.main.bounds.width == 320 {
                return UIFont.systemFont(ofSize: 15)
            }
            else if UIScreen.main.bounds.width == 414 {
                return UIFont.systemFont(ofSize: 22)
            }
            else if UIScreen.main.bounds.width == 375 {
                return UIFont.systemFont(ofSize: 20)
            }
            else {
                return UIFont.systemFont(ofSize: 20)
            }
        }
        var monthFont: UIFont! {
            if UIScreen.main.bounds.width == 320 {
                return UIFont.boldSystemFont(ofSize: 17)
            }
            else if UIScreen.main.bounds.width == 414 {
                return UIFont.boldSystemFont(ofSize: 25)
            }
            else if UIScreen.main.bounds.width == 375 {
                return UIFont.boldSystemFont(ofSize: 22)
            }
            else {
                return UIFont.boldSystemFont(ofSize: 22)
            }
        }
        var msgFont: UIFont! {
            if UIScreen.main.bounds.width == 320 {
                return UIFont.systemFont(ofSize: 11)
            }
            else if UIScreen.main.bounds.width == 414 {
                return UIFont.systemFont(ofSize: 15)
            }
            else if UIScreen.main.bounds.width == 375 {
                return UIFont.systemFont(ofSize: 11)
            }
            else {
                return UIFont.systemFont(ofSize: 11)
            }
        }
        lblMonthAndYear.font = monthFont
        lblDayString.font = dayCountFont
    }
}

//MARK:- CollectionView Delegate and Datasource.
extension CalendarView: DelegateForCalendarView {
    
    func scrollViewDidScrollCustom(_ scrollView: UIScrollView) {
        if isReloadToReset {
            scrollView.contentOffset = CollectionViewPagging.shared.setContentOffset(forProposedContentOffset: scrollView.contentOffset, withScrollingVelocity: CGPoint(x: 0, y: 0), collectionView: calendarCollectionView)
            scrollView.layoutIfNeeded()
        }
        btnReset.isEnabled = false
        let cellArr = getVisibleCells()
        setupTheDialScrollSetting(CellArray: cellArr, IsContinue: true)
    }
    func scrollViewDidEndDeceleratingCustom(_ scrollView: UIScrollView) {
        btnReset.isEnabled = true
        isReloadToReset = false
        let cellArr = getVisibleCells()
        setupTheDialScrollSetting(CellArray: cellArr, IsContinue: false)
    }
}
extension FloatingPoint {
    var degreesToRadians: Self { return self * .pi / 180 }
    var radiansToDegrees: Self { return self * 180 / .pi }
}
