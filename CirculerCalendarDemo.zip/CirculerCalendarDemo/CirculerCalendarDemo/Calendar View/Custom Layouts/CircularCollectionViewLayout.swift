//
//  CircularCollectionViewLayout.swift
//  CustomCircularCollectionView_Bvk
//
//  Created by Bhavik's Mac on 04/10/18.
//  Copyright © 2018 Bhavik Barot. All rights reserved.
//

import UIKit
import Foundation

/**
 This custom collection view layout is used for providing circular UI to the collection view.
 - Authors:
 - Created By - Bhavik Barot
 - Modified By - Bhavik Barot
 - Date:
 - Created At - 04/10/2018
 - Modified At - date
 - Version: 1.0
 - Remark: Any line change will efect on the collectionview layout(This is used for the specific purpose for specific task which have some rules.).
 */
class CircularCollectionViewLayoutAttributes: UICollectionViewLayoutAttributes {
    var anchorPoint = CGPoint(x: 0.5, y: 0.5)
    var angle: CGFloat = 0 {
        didSet {
            zIndex = Int(angle * 1000000)
            transform = CGAffineTransform(rotationAngle: angle)
        }
    }
    override func copy(with zone: NSZone? = nil) -> Any {
        let copiedAttributes: CircularCollectionViewLayoutAttributes = super.copy(with: zone) as! CircularCollectionViewLayoutAttributes
        copiedAttributes.anchorPoint = self.anchorPoint
        copiedAttributes.angle = self.angle
        return copiedAttributes
    }
}

class CircularCollectionViewLayout: UICollectionViewLayout {
    
    var itemSize: CGSize! {
        if UIScreen.main.bounds.width == 320 {
            return CGSize(width: 50, height: 50)
        }
        else if UIScreen.main.bounds.width == 414 {
            return CGSize(width: 80, height: 85)
        }
        else if UIScreen.main.bounds.width == 375 {
            return CGSize(width: 70, height: 70)
        }
        else {
            return CGSize(width: 70, height: 70)
        }
    }
    
    var radius: CGFloat! {
        if UIScreen.main.bounds.width == 320 {
            return 85
        }
        else if UIScreen.main.bounds.width == 414 {
            return 120
        }
        else if UIScreen.main.bounds.width == 375 {
            return 105
        }
        else {
            return 105
        }
    }
    var anglePerItem: CGFloat {
        return 0.90
    }
    
    var reloadCount: Int! = 0
    
    override var collectionViewContentSize: CGSize {
        return CGSize(width: CGFloat(collectionView!.numberOfItems(inSection: 0)) * itemSize.width, height: collectionView!.bounds.height)
    }
    
    
    override class var layoutAttributesClass: AnyClass {
        return CircularCollectionViewLayoutAttributes.self
    }
    
    var attributesList = [CircularCollectionViewLayoutAttributes]()
    var attributesListForAll = [CircularCollectionViewLayoutAttributes]()
    
    var angleAtExtreme: CGFloat {
        return collectionView!.numberOfItems(inSection: 0) > 0 ?
            -CGFloat(collectionView!.numberOfItems(inSection: 0) - 1) * anglePerItem : 0
    }
    var angle: CGFloat {
        return angleAtExtreme * collectionView!.contentOffset.x / (collectionViewContentSize.width -
            collectionView!.bounds.width)
    }
    
    override func prepare() {
        super.prepare()
        setArrtibutesForTheCell(CollectionView: collectionView)
    }
    
    func setArrtibutesForTheCell(CollectionView collectionView: UICollectionView?) {
        
        let theta = atan2(collectionView!.bounds.width / 2.0,
                          radius + (itemSize.height / 2.0) - (collectionView!.bounds.height / 2.0))
        
        var startIndex = 0
        var endIndex = collectionView!.numberOfItems(inSection: 0) - 1
        
        if (angle < -theta) {
            startIndex = Int(floor((-theta - angle) / anglePerItem))
        }
        endIndex = min(endIndex, Int(ceil((theta - angle) / anglePerItem)))
        if (endIndex < startIndex) {
            endIndex = 0
            startIndex = 0
        }
        
        let anchorPointY = ((itemSize.height / 2.0) + radius) / itemSize.height
        let centerX = collectionView!.contentOffset.x + (collectionView!.bounds.width) / 2.0
        var centerY: CGFloat!{
            if UIScreen.main.bounds.width == 320 {
                return 25
            }
            else if UIScreen.main.bounds.width == 414 {
                return 40.0
            }
            else if UIScreen.main.bounds.width == 375 {
                return 35.0
            }
            else {
                return 35.0
            }
        }
        
        //This setup will gives the set of 5 elements at a time for the circular calendar.
        attributesList = (startIndex...endIndex).map { (i)
            -> CircularCollectionViewLayoutAttributes in
            
            let attributes = CircularCollectionViewLayoutAttributes(forCellWith: NSIndexPath(item: i, section: 0) as IndexPath)
            attributes.size = self.itemSize
            
            attributes.center = CGPoint(x: centerX, y: CGFloat(centerY))
            
            attributes.angle = self.angle + (self.anglePerItem * CGFloat(i))
            
            attributes.anchorPoint = CGPoint(x: 0.5, y: anchorPointY)
            
            return attributes
        }
    }
 
    override func layoutAttributesForElements(in rect: CGRect) -> [UICollectionViewLayoutAttributes]? {
        return attributesList
    }
    
    override func layoutAttributesForItem(at indexPath: IndexPath) -> UICollectionViewLayoutAttributes? {
        return attributesList[indexPath.row]
    }
    
    override func shouldInvalidateLayout(forBoundsChange newBounds: CGRect) -> Bool {
        return true
    }
    
    //MARK:- Snapping Operation (Pagging)
    override func targetContentOffset(forProposedContentOffset proposedContentOffset: CGPoint, withScrollingVelocity velocity: CGPoint) -> CGPoint {
        var finalContentOffset = proposedContentOffset
        let factor = -angleAtExtreme/(collectionViewContentSize.width -
            collectionView!.bounds.width)
        let proposedAngle = proposedContentOffset.x*factor
        let ratio = proposedAngle/anglePerItem
        var multiplier: CGFloat
        if (velocity.x > 0) {
            multiplier = ceil(ratio)
        } else if (velocity.x < 0) {
            multiplier = floor(ratio)
        } else {
            multiplier = round(ratio)
        }
        finalContentOffset.x = multiplier*anglePerItem/factor
        return finalContentOffset
    }
}
